import hashlib
import pickle
from pathlib import Path
from typing import Optional

from ai.web.search_cache.search_cache_entry import SearchCacheEntry


class SearchCache:
    """
    Persistent cache for search results.

    Features
    --------
    • Disk-based storage
    • Query hashing
    • Version checking
    • Corruption recovery
    • Last access tracking
    """

    ############################################################

    CACHE_VERSION = 1

    CACHE_DIR = Path("data/cache/search")

    ############################################################

    def __init__(self):

        self.CACHE_DIR.mkdir(

            parents=True,

            exist_ok=True

        )

    ############################################################

    def _filename(

        self,

        query: str

    ) -> Path:

        digest = hashlib.sha256(

            query.strip().lower().encode("utf-8")

        ).hexdigest()

        return self.CACHE_DIR / f"{digest}.pkl"

    ############################################################

    def load(

        self,

        query: str

    ) -> Optional[SearchCacheEntry]:

        path = self._filename(query)

        if not path.exists():

            print("[SearchCache] MISS")

            return None

        try:

            with open(path, "rb") as file:

                entry: SearchCacheEntry = pickle.load(file)

            ####################################################
            # Version check
            ####################################################

            if getattr(entry, "version", 0) != self.CACHE_VERSION:

                print("[SearchCache] VERSION MISMATCH")

                path.unlink(missing_ok=True)

                return None

            ####################################################
            # Update last access
            ####################################################

            entry.touch()

            with open(path, "wb") as file:

                pickle.dump(entry, file)

            print("[SearchCache] HIT")

            return entry

        except Exception as e:

            print(f"[SearchCache] Corrupted cache: {e}")

            try:

                path.unlink()

            except Exception:

                pass

            return None

    ############################################################

    def save(

        self,

        query: str,

        results

    ):

        entry = SearchCacheEntry(

            query=query,

            results=results,

            version=self.CACHE_VERSION

        )

        path = self._filename(query)

        with open(path, "wb") as file:

            pickle.dump(entry, file)

        print("[SearchCache] SAVED")

    ############################################################

    def clear(self):

        count = 0

        for file in self.CACHE_DIR.glob("*.pkl"):

            try:

                file.unlink()

                count += 1

            except Exception:

                pass

        print(f"[SearchCache] Cleared {count} files.")

    ############################################################

    def stats(self):

        files = list(

            self.CACHE_DIR.glob("*.pkl")

        )

        total = sum(

            file.stat().st_size

            for file in files

        )

        return {

            "entries": len(files),

            "size_bytes": total,

            "size_mb": round(

                total / (1024 * 1024),

                2

            )

        }