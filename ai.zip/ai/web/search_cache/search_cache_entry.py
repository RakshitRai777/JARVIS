from dataclasses import dataclass, field
from datetime import datetime
from typing import List

from ai.web.web_result import WebResult


@dataclass
class SearchCacheEntry:
    """
    Represents one cached search query.

    Stores
    ------
    • Original query
    • Search results
    • Cache version
    • Creation time
    • Last access time
    """

    ############################################################

    query: str

    results: List[WebResult]

    ############################################################

    version: int = 1

    created_at: datetime = field(default_factory=datetime.utcnow)

    last_accessed: datetime = field(default_factory=datetime.utcnow)

    ############################################################

    def touch(self):

        """
        Updates the last access timestamp.
        """

        self.last_accessed = datetime.utcnow()