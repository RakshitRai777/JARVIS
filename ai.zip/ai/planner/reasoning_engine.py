from ai.planner.execution_plan import ExecutionPlan
from ai.planner.execution_step import ExecutionStep
from ai.verification.verification_rule import VerificationRule


class ReasoningEngine:
    """
    Improves an ExecutionPlan before execution.

    Responsibilities
    ----------------
    • Expand plans
    • Insert wait steps
    • Insert verification steps
    • Insert focus steps

    It NEVER executes anything.
    """

    ############################################################

    def improve(
        self,
        plan: ExecutionPlan,
    ) -> ExecutionPlan:

        improved = ExecutionPlan()

        ########################################################

        for step in plan.steps:

            improved.add_step(step)

            if self._is_open_application(step):
                command = step.parameters.get(
                    "command",
                    "",
                )

                app = command.replace(
                    "Open",
                    "",

                ).replace(
                    "open",
                    ""
                ).strip()

                step.verification_rule = VerificationRule(
                    rule_type="window_exists",
                    expected=app,
                )

            ####################################################
            # Rule 1
            # Opening an application
            ####################################################

            if self._is_open_application(step):

                improved.add_step(

                    ExecutionStep(

                        action="wait",

                        parameters={

                            "seconds": 2,

                        },

                        description="Wait for application to open.",

                    )

                )

                improved.add_step(

                    ExecutionStep(

                        action="focus_window",

                        parameters={

                            "application": step.parameters["command"],

                        },

                        description="Focus application window.",

                    )

                )

        ########################################################

        return improved

    ############################################################

    def _is_open_application(
        self,
        step: ExecutionStep,
    ) -> bool:

        if step.action != "tool":

            return False

        command = step.parameters.get(

            "command",

            "",

        ).lower()

        prefixes = (

            "open ",

            "launch ",

            "start ",

            "run ",

        )

        return command.startswith(prefixes)